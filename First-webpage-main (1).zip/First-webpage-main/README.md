# Student Digital Locker

A beginner-friendly, full-stack hackathon prototype for a private student document locker. The React app calls a Flask REST API; SQLite keeps student accounts, profiles and document metadata, while files are stored in the backend's local `uploads/` directory.

> **Prototype notice:** This project is for local demos and learning. Do not upload real identity, financial, health, academic-confidential or otherwise sensitive documents. A production service needs a security review, HTTPS, secure secrets and deployment configuration, stronger upload scanning and storage controls, CSRF protection, backups, monitoring and a privacy/legal review.

## Features

- Student registration, sign-in and sign-out with hashed passwords and HTTP-only session cookies.
- Protected React routes and authenticated REST endpoints.
- Private profile, searchable and filterable document list, upload progress, view/download and confirmed delete.
- Server-side file-extension and 10 MB request-size checks.
- Responsive dashboard, empty states, seeded demo student and a downloadable sample PDF.

## Project layout

```text
project1/
├── README.md
├── backend/
│   ├── app.py
│   ├── database.py
│   ├── models.py
│   ├── requirements.txt
│   ├── routes/
│   │   ├── __init__.py
│   │   ├── auth.py
│   │   ├── documents.py
│   │   └── profile.py
│   └── uploads/                 # Created on first backend run; ignored by git
└── frontend/
    ├── index.html
    ├── package.json
    ├── package-lock.json
    ├── vite.config.js
    └── src/
        ├── App.jsx
        ├── main.jsx
        ├── styles.css
        ├── components/
        │   ├── DocumentCard.jsx
        │   ├── Navbar.jsx
        │   ├── SearchBar.jsx
        │   ├── Sidebar.jsx
        │   └── UploadForm.jsx
        ├── pages/
        │   ├── Dashboard.jsx
        │   ├── Documents.jsx
        │   ├── Login.jsx
        │   ├── PersonalInfo.jsx
        │   ├── Profile.jsx
        │   ├── Register.jsx
        │   └── Upload.jsx
        └── services/
            └── api.js
```

## Requirements and installation

Use Python 3.10+ and Node.js 20+ (with npm). From a terminal, open **two terminals** in this `project1` folder.

### Backend terminal

```powershell
cd backend
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python app.py
```

If PowerShell blocks environment activation, use `.\.venv\Scripts\python.exe -m pip install -r requirements.txt`, then `.\.venv\Scripts\python.exe app.py`.

The API starts at `http://localhost:5000`. On its first run it creates `backend/locker.db`, the tables, a demo account and a sample PDF in `backend/uploads/`.

### Frontend terminal

```powershell
cd frontend
npm install
npm run dev
```

Open the Vite URL printed in the terminal (normally `http://localhost:5173`). The frontend automatically uses the same hostname on port `5000` for its API requests; to use a different backend, create `frontend/.env` with `VITE_API_URL=http://localhost:5000/api`.

## Demo login

- Email: `demo@student.edu`
- Password: `Student123!`

Or use **Create an account** to make a separate student account. Use made-up demo data only.

## How React talks to Flask

`frontend/src/services/api.js` wraps `fetch` requests and includes browser credentials so Flask's HTTP-only session cookie is sent with API calls. File uploads use `XMLHttpRequest` for progress reporting. Flask-CORS allows the local Vite origin with credentials. The browser receives JSON for metadata and a file response for view/download operations. No password or uploaded file is stored in browser local storage.

## REST API

All routes except health, register, login and logout require a logged-in session. Requests that update profile data use JSON; document uploads use `multipart/form-data`.

| Method | Endpoint | Purpose |
| --- | --- | --- |
| GET | `/api/health` | Check that the API is running |
| POST | `/api/register` | Create account and start session |
| POST | `/api/login` | Verify credentials and start session |
| POST | `/api/logout` | End current session |
| GET | `/api/me` | Get the signed-in student |
| GET | `/api/profile` | Get private student and personal information |
| PUT | `/api/profile` | Update profile and personal information |
| GET | `/api/documents?search=&category=All` | List the current student's documents |
| POST | `/api/documents` | Upload a document (name, category, description, file) |
| GET | `/api/documents/<id>` | View a document owned by the current student |
| GET | `/api/documents/<id>/download` | Download an owned document |
| DELETE | `/api/documents/<id>` | Delete an owned document |

Document ownership is checked against the authenticated user in every list, file and delete query. A document ID alone never grants access. Allowed filename extensions are PDF, JPG/JPEG, PNG, DOC and DOCX; the request-size limit is 10 MB.

## Try the main flows

1. Run both servers and sign in with the demo account.
2. Open **My documents** to search by document name or choose a category.
3. Open **Upload document**, enter a name, choose a category, select a sample file under 10 MB and submit. Watch the progress indicator.
4. From **My documents**, view or download the new file. Choose delete and confirm to remove it.
5. Open **Personal information** to edit the sample student profile.
6. Register a second test account and verify that it cannot see the demo account's documents.

## Database

SQLite tables are initialized by `backend/models.py` when the Flask app starts:

- `users`: account email, Werkzeug password hash and core student information.
- `personal_information`: phone, college and address, keyed to its student.
- `documents`: owner ID, display name, category, generated storage filename, type, size, date and description.

Foreign keys cascade when a student is removed. Demo seed data is inserted once; deleting the generated database and restarting the backend re-creates it. Never commit `locker.db`, `.env`, secrets or private uploads.

## Hackathon presentation

- **Problem:** Students keep certificates, marksheets, IDs, resumes and project files in scattered places, making them hard to find and manage.
- **Solution:** A student's own digital locker that organizes personal and academic documents with a private profile.
- **Key features:** Account-based locker, search and categories, upload progress, file preview/download/delete, profile details and a responsive dashboard.
- **Technology:** React, React Router, CSS, Flask REST API, SQLite and Werkzeug password hashing.
- **Future improvements:** Encrypted object storage, malware scanning and content-based file verification, MFA, university single sign-on, audit history, backups, accessibility/localization, expiring share links, and a reviewed production security/privacy design.
- **Demo pitch:** “Student Digital Locker gives every student one organized place for the documents that move their education forward. Sign in, find a file in seconds, and keep your next opportunity close.”

## Before deployment

The default secret key and Flask debug mode are local-development settings. Before any real deployment, configure a random secret outside source control, disable debug mode, use HTTPS and secure cookies, deploy behind a hardened server, restrict CORS to the real frontend origin, add CSRF protection and rate limiting, scan and validate file content, use private managed storage, and complete a professional security and privacy review. This prototype is not a certified secure document vault.
