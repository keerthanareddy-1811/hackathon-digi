import { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import DocumentCard from "../components/DocumentCard.jsx";
import SearchBar from "../components/SearchBar.jsx";
import { EmptyDocuments } from "./Dashboard.jsx";
import { api } from "../services/api.js";

export default function Documents() {
  const [searchParams] = useSearchParams();
  const [documents, setDocuments] = useState([]);
  const [search, setSearch] = useState(() => searchParams.get("search") || "");
  const [category, setCategory] = useState("All");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(true);
  async function load() {
    setBusy(true); setError("");
    try { const result = await api.documents(search, category); setDocuments(result.documents); }
    catch (err) { setError(err.message); }
    finally { setBusy(false); }
  }
  useEffect(() => { const timer = setTimeout(load, 180); return () => clearTimeout(timer); }, [search, category]);
  async function remove(document) {
    if (!window.confirm(`Delete "${document.name}"? This can't be undone.`)) return;
    try { await api.deleteDocument(document.id); setDocuments((items) => items.filter((item) => item.id !== document.id)); }
    catch (err) { setError(err.message); }
  }
  return <>
    <div className="page-intro"><div><span className="eyebrow">YOUR PERSONAL ARCHIVE</span><h2>My documents<span className="heading-period">.</span></h2><p>Everything important, in one easy-to-find place.</p></div><div className="doc-count"><strong>{documents.length.toString().padStart(2, "0")}</strong><span>DOCUMENTS</span></div></div>
    <SearchBar search={search} onSearch={setSearch} category={category} onCategory={setCategory} />
    {error && <div className="alert alert-error">{error}</div>}
    {busy ? <div className="loading-state">Gathering your documents...</div> : documents.length ?
      <div className="document-grid">{documents.map((document) => <DocumentCard key={document.id} document={document} onDelete={remove} />)}</div> :
      <EmptyDocuments />}
    <footer className="app-footer"><span>Student Digital Locker <b>·</b> Your archive, your pace</span><span>DEMO PROTOTYPE · DO NOT STORE REAL PERSONAL DOCUMENTS</span></footer>
  </>;
}
