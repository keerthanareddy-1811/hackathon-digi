import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../App.jsx";

export default function Register() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  async function submit(event) {
    event.preventDefault(); setBusy(true); setError("");
    const form = new FormData(event.currentTarget);
    if (form.get("password") !== form.get("confirm")) {
      setError("Those passwords don't match. Please try again."); setBusy(false); return;
    }
    try {
      await register({ name: form.get("name"), email: form.get("email"), password: form.get("password") });
      navigate("/");
    } catch (err) { setError(err.message); }
    finally { setBusy(false); }
  }
  return (
    <main className="auth-page">
      <section className="auth-hero register-hero">
        <Link to="/login" className="brand auth-brand"><span className="brand-mark">L</span><span>locker<span className="brand-dot">.</span></span></Link>
        <div className="hero-copy"><div className="eyebrow"><span /> YOUR SPACE STARTS HERE</div><h1>Less searching.<br /><span>More doing.</span></h1><p>A calmer place for every certificate, project and plan for the future.</p><div className="feature-stamps"><span>✦ ACADEMICS</span><span>✦ PROJECTS</span><span>✦ YOUR FUTURE</span></div></div>
        <div className="hero-foot"><span>BUILT FOR STUDENTS, BY STUDENTS</span><span>02 — YOUR DIGITAL DESK</span></div>
      </section>
      <section className="auth-panel">
        <div className="auth-panel-top">ALREADY HAVE AN ACCOUNT? <Link to="/login">Sign in <span>↗</span></Link></div>
        <div className="auth-form-wrap"><div className="auth-icon">✳</div><div className="eyebrow">START YOUR LOCKER</div><h2>Make it yours.</h2><p className="auth-subtitle">One account. A little less to carry.</p>
          {error && <div className="alert alert-error">{error}</div>}
          <form className="auth-form" onSubmit={submit}>
            <label className="field-label">Full name<input name="name" required maxLength="100" placeholder="Your name" autoComplete="name" /></label>
            <label className="field-label">College email<input type="email" name="email" required placeholder="you@college.edu" autoComplete="email" /></label>
            <label className="field-label">Password <small>At least 8 characters</small><input type="password" name="password" minLength="8" required placeholder="Create a password" autoComplete="new-password" /></label>
            <label className="field-label">Confirm password<input type="password" name="confirm" minLength="8" required placeholder="Enter it once more" autoComplete="new-password" /></label>
            <button className="button button-dark auth-submit" disabled={busy}>{busy ? "Creating your locker..." : "Create your locker"} <span>↗</span></button>
          </form>
          <div className="auth-security">⌑ &nbsp;PRIVATE BY DESIGN <span>·</span> PROTOTYPE — DON'T STORE REAL DOCUMENTS</div>
        </div>
      </section>
    </main>
  );
}
