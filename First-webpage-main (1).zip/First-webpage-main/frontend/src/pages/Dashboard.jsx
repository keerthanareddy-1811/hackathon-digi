import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import DocumentCard from "../components/DocumentCard.jsx";
import { api } from "../services/api.js";

const CATEGORY_COLORS = ["#2e8067", "#527fce", "#db9955", "#aa77c1", "#d77979", "#628b99", "#9a9b75"];

export default function Dashboard({ user }) {
  const navigate = useNavigate();
  const [documents, setDocuments] = useState([]);
  const [profile, setProfile] = useState(null);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  async function load() {
    try {
      const [docs, info] = await Promise.all([api.documents(), api.profile()]);
      setDocuments(docs.documents); setProfile(info.profile);
    } catch (err) { setError(err.message); }
  }
  useEffect(() => { load(); }, []);
  async function remove(document) {
    if (!window.confirm(`Delete "${document.name}"? This can't be undone.`)) return;
    try {
      await api.deleteDocument(document.id);
      setDocuments((items) => items.filter((item) => item.id !== document.id));
    } catch (err) { setError(err.message); }
  }
  const categoryCounts = documents.reduce((counts, item) => ({ ...counts, [item.category]: (counts[item.category] || 0) + 1 }), {});
  return (
    <>
      <section className="welcome-banner"><div><span className="eyebrow light-eyebrow">YOUR PERSONAL DIGITAL LOCKER</span><h2>A good day to get<br />things <em>in order.</em></h2><p>Store, manage and access your important academic documents from one private locker.</p><Link className="button button-light" to="/upload">Upload a document <span>↗</span></Link></div><div className="banner-art"><span className="art-orbit orbit-one" /><span className="art-orbit orbit-two" /><div className="art-folder"><span>▤</span><small>YOUR FILES</small></div><span className="art-star star-one">✳</span><span className="art-star star-two">✦</span><span className="art-label">A PLACE<br />OF YOUR OWN</span></div></section>
      <div className="section-heading"><div><span className="eyebrow">AT A GLANCE</span><h2>Your overview</h2></div><span className="today-label">{new Date().toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric" })}</span></div>
      <form className="dashboard-search" onSubmit={(event) => { event.preventDefault(); navigate(`/documents?search=${encodeURIComponent(search)}`); }}>
        <label className="search-box"><span>⌕</span><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Find a document by name..." /><button type="submit">Search ↗</button></label>
      </form>
      {error && <div className="alert alert-error">{error}</div>}
      <div className="stats-grid">
        <div className="stat-card"><div className="stat-top"><span className="stat-icon green-icon">▤</span><span className="stat-tag">ALL FILES</span></div><strong>{documents.length.toString().padStart(2, "0")}</strong><span className="stat-description">Documents in your locker</span><div className="stat-line"><span style={{ width: `${Math.min(100, documents.length * 12)}%` }} /></div></div>
        <div className="stat-card"><div className="stat-top"><span className="stat-icon peach-icon">◷</span><span className="stat-tag">RECENT</span></div><strong>{documents.length ? new Date(documents[0].upload_date).toLocaleDateString(undefined, { month: "short", day: "numeric" }) : "—"}</strong><span className="stat-description">Last locker activity</span><div className="stat-note">Your space is up to date <span>✦</span></div></div>
        <div className="stat-card profile-stat"><div className="stat-top"><span className="stat-icon blue-icon">◎</span><span className="stat-tag">YOUR PROFILE</span></div><strong>{profile?.department || user?.department || "Add details"}</strong><span className="stat-description">{profile?.college || "Add your college information"}</span><Link to="/personal-information">Complete your profile ↗</Link></div>
      </div>
      <div className="overview-lower">
        <section className="overview-panel category-panel"><div className="panel-heading"><div><span className="eyebrow">YOUR COLLECTION</span><h2>By category</h2></div><Link to="/documents">View all ↗</Link></div>
          {documents.length ? <div className="category-list">{Object.entries(categoryCounts).map(([category, count], i) => <div className="category-row" key={category}><span className="category-dot" style={{ background: CATEGORY_COLORS[i % CATEGORY_COLORS.length] }} /><span>{category}</span><span className="category-count">{count.toString().padStart(2, "0")}</span><div className="category-bar"><i style={{ width: `${Math.max(8, (count / documents.length) * 100)}%`, background: CATEGORY_COLORS[i % CATEGORY_COLORS.length] }} /></div></div>)}</div> : <EmptyDocuments compact />}
        </section>
        <section className="overview-panel profile-panel"><div className="panel-heading"><div><span className="eyebrow">YOUR DETAILS</span><h2>Student profile</h2></div><Link to="/personal-information">Edit ↗</Link></div><div className="profile-summary"><span className="profile-avatar">{(profile?.name || user?.name || "S").charAt(0)}</span><div><strong>{profile?.name || user?.name}</strong><small>{profile?.email || user?.email}</small></div></div><div className="profile-detail"><span>STUDENT ID</span><strong>{profile?.student_id || "Not added yet"}</strong></div><div className="profile-detail"><span>DEPARTMENT</span><strong>{profile?.department || "Not added yet"}</strong></div><div className="profile-detail"><span>YEAR</span><strong>{profile?.year || "Not added yet"}</strong></div></section>
      </div>
      <section className="recent-section"><div className="section-heading compact-heading"><div><span className="eyebrow">PICK UP WHERE YOU LEFT OFF</span><h2>Recently added</h2></div><Link className="text-link" to="/documents">See all documents ↗</Link></div>
        {documents.length ? <div className="recent-list">{documents.slice(0, 2).map((doc) => <DocumentCard key={doc.id} document={doc} onDelete={remove} />)}</div> : <EmptyDocuments />}
      </section>
      <footer className="app-footer"><span>Student Digital Locker <b>·</b> A calmer space for your student life</span><span>DEMO PROTOTYPE · DO NOT STORE REAL PERSONAL DOCUMENTS</span></footer>
    </>
  );
}

export function EmptyDocuments({ compact = false }) {
  return <div className={`empty-state${compact ? " empty-compact" : ""}`}><span className="empty-icon">▤</span><h3>A little room for something new.</h3><p>Your documents will appear here once you add the first one.</p>{!compact && <Link className="button button-primary button-small" to="/upload">Upload your first document ↗</Link>}</div>;
}
