import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../App.jsx";

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  async function submit(event) {
    event.preventDefault();
    setBusy(true); setError("");
    const form = new FormData(event.currentTarget);
    try {
      await login({ email: form.get("email"), password: form.get("password") });
      navigate("/");
    } catch (err) { setError(err.message); }
    finally { setBusy(false); }
  }
  return (
    <>
    <main className="auth-page">
      <section className="auth-hero">
        <Link to="/login" className="brand auth-brand"><span className="brand-mark">L</span><span>locker<span className="brand-dot">.</span></span></Link>
        <div className="hero-copy"><div className="eyebrow"><span /> STUDENT DIGITAL LOCKER</div><h1>Your whole<br />academic life.<br /><span>In one place.</span></h1><p>Your documents. Your information. One secure place.</p>
          <div className="hero-preview"><div className="preview-top"><span>MY LOCKER</span><span>✦ PRIVATE SPACE</span></div><div className="preview-doc"><span className="preview-file">PDF</span><span><strong>Academic transcript</strong><small>Mark Sheets · 248 KB</small></span><span className="preview-check">✓</span></div><div className="preview-doc"><span className="preview-file preview-blue">DOC</span><span><strong>Internship resume</strong><small>Resume · 1.2 MB</small></span><span className="preview-check">✓</span></div></div>
        </div>
        <div className="hero-foot"><span>BUILT FOR STUDENTS, BY STUDENTS</span><span>01 — YOUR DIGITAL DESK</span></div>
      </section>
      <section className="auth-panel">
        <div className="auth-panel-top">NEW TO LOCKER? <Link to="/register">Create an account <span>↗</span></Link></div>
        <div className="auth-form-wrap"><div className="auth-icon">✳</div><div className="eyebrow">WELCOME BACK</div><h2>Good to see you.</h2><p className="auth-subtitle">Sign in to pick up right where you left off.</p>
          {error && <div className="alert alert-error">{error}</div>}
          <form className="auth-form" onSubmit={submit}>
            <label className="field-label">Email address<input type="email" name="email" autoComplete="email" required placeholder="you@college.edu" /></label>
            <label className="field-label">Password<input type="password" name="password" autoComplete="current-password" required placeholder="Enter your password" /></label>
            <button className="button button-dark auth-submit" disabled={busy}>{busy ? "Signing in..." : "Sign in to your locker"} <span>↗</span></button>
          </form>
          <div className="demo-hint"><strong>Try the demo</strong><span>demo@student.edu</span><span>Student123!</span><small>Or create your own student account.</small></div>
          <div className="auth-security">⌑ &nbsp;PRIVATE BY DESIGN <span>·</span> PROTOTYPE — DON'T STORE REAL DOCUMENTS</div>
        </div>
      </section>
    </main>
    <section className="pitch-section">
      <div className="pitch-heading"><span className="eyebrow">THE IDEA BEHIND THE LOCKER</span><h2>Less lost. More <em>life.</em></h2><p>Made for the parts of student life you want to keep close.</p></div>
      <div className="pitch-grid">
        <article><span>01 / THE PROBLEM</span><h3>Important things, everywhere.</h3><p>Certificates, marksheets and project files get scattered across drives, inboxes and devices—right when students need them.</p></article>
        <article><span>02 / THE SOLUTION</span><h3>One place that feels like yours.</h3><p>A personal locker to organize academic documents and student information behind an individual account.</p></article>
        <article><span>03 / THE TOOLKIT</span><h3>Small, simple, connected.</h3><p>React · React Router · CSS · Flask REST API · SQLite · Werkzeug password hashing.</p></article>
        <article><span>04 / WHAT'S NEXT</span><h3>Built to grow thoughtfully.</h3><p>Future ideas: multi-factor sign-in, malware scanning, encrypted storage, university login and accessible sharing.</p></article>
      </div>
      <div className="pitch-footer"><span>STUDENT DIGITAL LOCKER</span><span>HACKATHON PROTOTYPE — FOR DEMO DATA ONLY</span></div>
    </section>
    </>
  );
}
