import { Link } from "react-router-dom";
import { useAuth } from "../App.jsx";

export default function Profile() {
  const { user } = useAuth();
  return <>
    <div className="page-intro"><div><span className="eyebrow">YOUR ACCOUNT</span><h2>Profile<span className="heading-period">.</span></h2><p>A quick look at the person behind the locker.</p></div></div>
    <section className="account-card"><div className="account-cover"><span>STUDENT DIGITAL LOCKER</span><span>✳ &nbsp; YOUR SPACE</span></div><div className="account-identity"><span className="account-avatar">{user?.name?.charAt(0)?.toUpperCase() || "S"}</span><div><h3>{user?.name}</h3><span>{user?.email}</span></div><Link className="button button-outline button-small" to="/personal-information">Edit details ↗</Link></div><div className="account-note"><span className="privacy-icon">✦</span><div><strong>You're in control of your space.</strong><p>Your account keeps your personal information and documents separate from every other student.</p></div></div></section>
    <div className="prototype-banner"><b>Prototype account</b><p>This hackathon demo is built to show how a student locker could work. Don't upload real identity, financial or confidential documents.</p></div>
    <footer className="app-footer"><span>Student Digital Locker <b>·</b> A calmer space for your student life</span><span>DEMO PROTOTYPE · NOT FOR REAL DOCUMENTS</span></footer>
  </>;
}
