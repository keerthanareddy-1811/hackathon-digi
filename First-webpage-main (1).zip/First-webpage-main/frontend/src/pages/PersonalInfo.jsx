import { useEffect, useState } from "react";
import { useAuth } from "../App.jsx";
import { api } from "../services/api.js";

export default function PersonalInfo() {
  const { setUser } = useAuth();
  const [profile, setProfile] = useState({});
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  useEffect(() => { api.profile().then((result) => setProfile(result.profile)).catch((err) => setError(err.message)); }, []);
  function change(event) { setProfile((current) => ({ ...current, [event.target.name]: event.target.value })); }
  async function submit(event) {
    event.preventDefault(); setBusy(true); setError(""); setMessage("");
    try {
      const result = await api.updateProfile(profile);
      setProfile(result.profile);
      setUser((current) => ({ ...current, ...result.profile }));
      setMessage("Your information has been saved.");
    }
    catch (err) { setError(err.message); }
    finally { setBusy(false); }
  }
  return <>
    <div className="page-intro"><div><span className="eyebrow">A LITTLE ABOUT YOU</span><h2>Personal information<span className="heading-period">.</span></h2><p>Keep your student details together and up to date.</p></div></div>
    {error && <div className="alert alert-error">{error}</div>}{message && <div className="alert alert-success">{message}</div>}
    <form className="info-form" onSubmit={submit}><div className="info-form-heading"><span className="profile-avatar">{(profile.name || "S").charAt(0)}</span><div><h3>Your student details</h3><p>Only visible to you in your private locker.</p></div></div>
      <div className="form-grid">
        <label className="field-label">Full name<input name="name" value={profile.name || ""} onChange={change} required /></label>
        <label className="field-label">Student ID<input name="student_id" value={profile.student_id || ""} onChange={change} placeholder="e.g. STU2024001" /></label>
        <label className="field-label">Email address<input type="email" name="email" value={profile.email || ""} onChange={change} required /></label>
        <label className="field-label">Phone number<input type="tel" name="phone" value={profile.phone || ""} onChange={change} placeholder="+1 555 000 0000" /></label>
        <label className="field-label">College / university<input name="college" value={profile.college || ""} onChange={change} placeholder="Your institution" /></label>
        <label className="field-label">Department<input name="department" value={profile.department || ""} onChange={change} placeholder="e.g. Computer Science" /></label>
        <label className="field-label">Year of study<select name="year" value={profile.year || ""} onChange={change}><option value="">Select year</option>{["1st Year", "2nd Year", "3rd Year", "4th Year", "Graduate"].map((year) => <option key={year}>{year}</option>)}</select></label>
        <label className="field-label full-width">Address<textarea name="address" rows="3" value={profile.address || ""} onChange={change} placeholder="Your mailing address (optional)" /></label>
      </div>
      <div className="info-form-footer"><span>🔒 Your information stays private to your account.</span><button className="button button-primary" disabled={busy}>{busy ? "Saving..." : "Save changes"} <span>↗</span></button></div>
    </form>
    <footer className="app-footer"><span>Student Digital Locker <b>·</b> Your information, your choice</span><span>DEMO PROTOTYPE · DO NOT STORE REAL PERSONAL DOCUMENTS</span></footer>
  </>;
}
