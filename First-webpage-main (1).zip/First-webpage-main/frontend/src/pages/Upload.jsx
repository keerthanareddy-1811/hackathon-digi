import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import UploadForm from "../components/UploadForm.jsx";
import { uploadDocument } from "../services/api.js";

export default function Upload() {
  const navigate = useNavigate();
  const [progress, setProgress] = useState(0);
  const [busy, setBusy] = useState(false);
  const [success, setSuccess] = useState(false);
  async function submit(form, showError) {
    setBusy(true); setProgress(0); setSuccess(false);
    try {
      await uploadDocument(form, setProgress);
      setSuccess(true);
      setTimeout(() => navigate("/documents"), 900);
    } catch (error) { showError(error.message); }
    finally { setBusy(false); }
  }
  return <>
    <div className="page-intro"><div><span className="eyebrow">ADD TO YOUR ARCHIVE</span><h2>Save something<span className="heading-period">.</span></h2><p>One less thing to worry about finding later.</p></div><Link className="text-link" to="/documents">← Back to documents</Link></div>
    {success && <div className="alert alert-success">Your document is safely in your locker. Taking you to your documents...</div>}
    <div className="upload-layout"><UploadForm onUpload={submit} progress={progress} busy={busy} /><aside className="upload-aside"><div className="aside-art"><span>✳</span><strong>Out of your<br />head. Into<br /><em>your locker.</em></strong><small>A spot for the things you'll need again.</small></div><div className="aside-tips"><span className="eyebrow">A FEW GOOD TO KNOWS</span><div><b>↗</b><p>PDFs and clear scans are easiest to read on any device.</p></div><div><b>✦</b><p>Give documents names that make sense to future you.</p></div><div><b>⌑</b><p>This demo locker is for sample files only.</p></div></div></aside></div>
    <footer className="app-footer"><span>Student Digital Locker <b>·</b> A calmer space for your student life</span><span>DEMO PROTOTYPE · DO NOT STORE REAL PERSONAL DOCUMENTS</span></footer>
  </>;
}
