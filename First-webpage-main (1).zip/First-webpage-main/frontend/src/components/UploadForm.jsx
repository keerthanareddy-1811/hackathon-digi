import { useState } from "react";
import { CATEGORIES } from "./SearchBar.jsx";
import { formatSize } from "./DocumentCard.jsx";

const ACCEPTED = ".pdf,.jpg,.jpeg,.png,.doc,.docx";
const MAX_BYTES = 10 * 1024 * 1024;

export default function UploadForm({ onUpload, progress, busy }) {
  const [file, setFile] = useState(null);
  const [error, setError] = useState("");
  function chooseFile(event) {
    const next = event.target.files?.[0] || null;
    setError("");
    if (next && next.size > MAX_BYTES) {
      setError("This file is too large. Please choose a file under 10 MB.");
      event.target.value = "";
      setFile(null);
      return;
    }
    setFile(next);
  }
  function submit(event) {
    event.preventDefault();
    setError("");
    const form = new FormData(event.currentTarget);
    if (!file) { setError("Choose a document to upload."); return; }
    if (file.size > MAX_BYTES) { setError("This file is too large. Please choose a file under 10 MB."); return; }
    form.set("file", file);
    onUpload(form, (message) => setError(message));
  }
  return (
    <form className="upload-form" onSubmit={submit}>
      <div className="form-section-title"><span>01</span><div><h2>Document details</h2><p>Give your file a name you'll remember.</p></div></div>
      <label className="field-label">Document name <span>*</span>
        <input name="name" required maxLength="100" placeholder="e.g. Semester 4 marksheet" />
      </label>
      <label className="field-label">Category <span>*</span>
        <select name="category" required defaultValue="">
          <option value="" disabled>Select a category</option>
          {CATEGORIES.slice(1).map((item) => <option key={item}>{item}</option>)}
        </select>
      </label>
      <label className="field-label">Description <small>Optional</small>
        <textarea name="description" rows="3" maxLength="500" placeholder="Add a note about this document..." />
      </label>
      <div className="form-section-title file-section"><span>02</span><div><h2>Your file</h2><p>Keep your important work close at hand.</p></div></div>
      <label className="drop-zone">
        <input type="file" name="file" accept={ACCEPTED} onChange={chooseFile} />
        <span className="upload-cloud">↑</span>
        {file ? <><strong>{file.name}</strong><span>{formatSize(file.size)} · Click to change</span></> :
          <><strong>Drop your file here, or <em>browse</em></strong><span>PDF, JPG, PNG, DOC or DOCX · Up to 10 MB</span></>}
      </label>
      {error && <div className="alert alert-error">{error}</div>}
      {busy && <div className="progress-wrap"><div className="progress-label"><span>Uploading your document...</span><span>{progress}%</span></div><div className="progress-track"><span style={{ width: `${progress}%` }} /></div></div>}
      <div className="upload-form-footer"><span>🔒 Your files stay private to your account</span><button className="button button-primary" disabled={busy}>{busy ? "Uploading..." : "Upload document"} <span>↗</span></button></div>
    </form>
  );
}
