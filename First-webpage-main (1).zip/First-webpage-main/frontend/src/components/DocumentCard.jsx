import { api } from "../services/api.js";

const categoryIcons = {
  Certificates: "✧", "Mark Sheets": "▤", "ID Documents": "▣", Resume: "▧",
  Projects: "⌘", Internship: "◈", Other: "▱",
};

export function formatSize(bytes) {
  if (bytes < 1024 * 1024) return `${Math.max(1, Math.round(bytes / 1024))} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export default function DocumentCard({ document, onDelete }) {
  const date = new Date(document.upload_date).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" });
  return (
    <article className="document-card">
      <div className={`file-icon file-${document.file_type.toLowerCase()}`}>
        <span>{document.file_type.slice(0, 3)}</span>
      </div>
      <div className="document-main">
        <h3 title={document.name}>{document.name}</h3>
        <div className="document-meta"><span>{document.category}</span><i />{document.file_type}<i />{formatSize(document.file_size)}</div>
        {document.description && <p className="document-description">{document.description}</p>}
        <div className="document-date">Added {date}</div>
      </div>
      <div className="document-actions">
        <a className="icon-action" href={api.fileUrl(document.id)} target="_blank" rel="noreferrer" title="View document" aria-label="View document">↗</a>
        <a className="icon-action" href={api.fileUrl(document.id, true)} title="Download document" aria-label="Download document">↓</a>
        <button className="icon-action delete-action" onClick={() => onDelete(document)} title="Delete document" aria-label="Delete document">×</button>
      </div>
      <span className="document-category-icon">{categoryIcons[document.category] || "▱"}</span>
    </article>
  );
}
