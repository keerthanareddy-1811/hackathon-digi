import { Link } from "react-router-dom";

export default function Navbar({ title, subtitle, action, onLogout }) {
  return (
    <header className="topbar">
      <div className="mobile-brand"><span className="brand-mark">L</span> locker<span className="brand-dot">.</span></div>
      <div className="topbar-title"><h1>{title}</h1>{subtitle && <p>{subtitle}</p>}</div>
      <div className="topbar-actions">
        {action && <Link className="button button-primary button-small" to={action.to}>{action.label}</Link>}
        <button className="mobile-signout" onClick={onLogout} title="Sign out" aria-label="Sign out">↪</button>
        <span className="topbar-status"><i /> All changes saved</span>
      </div>
    </header>
  );
}
