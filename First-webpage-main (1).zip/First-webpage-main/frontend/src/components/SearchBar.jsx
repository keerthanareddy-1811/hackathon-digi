export const CATEGORIES = ["All", "Certificates", "Mark Sheets", "ID Documents", "Resume", "Projects", "Internship", "Other"];

export default function SearchBar({ search, onSearch, category, onCategory }) {
  return (
    <div className="document-toolbar">
      <label className="search-box">
        <span>⌕</span>
        <input value={search} onChange={(event) => onSearch(event.target.value)} placeholder="Search your documents..." />
        <kbd>⌘ K</kbd>
      </label>
      <div className="filter-pills" aria-label="Filter documents by category">
        {CATEGORIES.map((item) => (
          <button key={item} className={`filter-pill${category === item ? " selected" : ""}`} onClick={() => onCategory(item)}>
            {item}
          </button>
        ))}
      </div>
    </div>
  );
}
