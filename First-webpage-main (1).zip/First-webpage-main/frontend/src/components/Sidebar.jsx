import { NavLink } from "react-router-dom";

const links = [
  { to: "/", label: "Overview", icon: "⌂", end: true },
  { to: "/documents", label: "My documents", icon: "▤" },
  { to: "/upload", label: "Upload document", icon: "＋" },
  { to: "/personal-information", label: "Personal information", icon: "◎" },
  { to: "/profile", label: "Profile", icon: "◉" },
];

export default function Sidebar({ user, onLogout }) {
  return (
    <aside className="sidebar">
      <NavLink to="/" className="brand">
        <span className="brand-mark">L</span>
        <span>locker<span className="brand-dot">.</span></span>
      </NavLink>
      <div className="sidebar-label">WORKSPACE</div>
      <nav className="side-nav">
        {links.map(({ to, label, icon, end }) => (
          <NavLink key={to} to={to} end={end} className={({ isActive }) => `nav-link${isActive ? " active" : ""}`}>
            <span className="nav-icon">{icon}</span>{label}
          </NavLink>
        ))}
      </nav>
      <div className="sidebar-bottom">
        <div className="privacy-card">
          <span className="privacy-icon">✦</span>
          <strong>Your space, just yours.</strong>
          <p>Your documents are private to your account.</p>
        </div>
        <button className="logout-link" onClick={onLogout}><span className="nav-icon">↪</span>Sign out</button>
        <div className="mini-user">
          <span className="avatar">{user?.name?.charAt(0)?.toUpperCase() || "S"}</span>
          <span className="mini-user-copy"><strong>{user?.name || "Student"}</strong><small>Student account</small></span>
          <span className="user-menu-dot">···</span>
        </div>
        <div className="prototype-note">DEMO PROTOTYPE · NOT FOR REAL DOCUMENTS</div>
      </div>
    </aside>
  );
}
