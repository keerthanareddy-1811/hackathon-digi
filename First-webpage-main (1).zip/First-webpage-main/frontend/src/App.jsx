import { createContext, useContext, useEffect, useState } from "react";
import { BrowserRouter, Link, Navigate, Outlet, Route, Routes, useLocation } from "react-router-dom";
import Sidebar from "./components/Sidebar.jsx";
import Navbar from "./components/Navbar.jsx";
import Dashboard from "./pages/Dashboard.jsx";
import Documents from "./pages/Documents.jsx";
import Login from "./pages/Login.jsx";
import PersonalInfo from "./pages/PersonalInfo.jsx";
import Profile from "./pages/Profile.jsx";
import Register from "./pages/Register.jsx";
import Upload from "./pages/Upload.jsx";
import { api } from "./services/api.js";

const AuthContext = createContext(null);
export const useAuth = () => useContext(AuthContext);

function ProtectedLayout() {
  const { user, loading, logout } = useAuth();
  const location = useLocation();
  if (loading) return <div className="app-loading"><span className="brand-mark">L</span><p>Opening your locker...</p></div>;
  if (!user) return <Navigate to="/login" replace state={{ from: location }} />;
  const routeInfo = {
    "/": ["A calmer way to keep it together.", "Your dashboard"],
    "/documents": ["Everything in its right place.", "My documents"],
    "/upload": ["Add a little something to your archive.", "Upload document"],
    "/personal-information": ["Keep your details close and current.", "Personal information"],
    "/profile": ["One space that belongs to you.", "Your profile"],
  }[location.pathname] || ["Your personal student space.", "Locker"];
  return <div className="app-shell"><Sidebar user={user} onLogout={logout} /><main className="main-area"><Navbar title={routeInfo[1]} subtitle={routeInfo[0]} action={location.pathname !== "/upload" ? { to: "/upload", label: "＋ Add a document" } : null} onLogout={logout} /><div className="page-content"><Outlet /></div></main><nav className="mobile-nav"><Link to="/">⌂<small>Home</small></Link><Link to="/documents">▤<small>Files</small></Link><Link to="/upload">＋<small>Upload</small></Link><Link to="/personal-information">◎<small>Info</small></Link><Link to="/profile">◉<small>Profile</small></Link></nav></div>;
}

function AppRoutes() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => { api.me().then((result) => setUser(result.user)).catch(() => setUser(null)).finally(() => setLoading(false)); }, []);
  async function login(credentials) {
    const result = await api.login(credentials);
    setUser(result.user);
  }
  async function register(details) {
    const result = await api.register(details);
    setUser(result.user);
  }
  async function logout() {
    try { await api.logout(); } finally { setUser(null); window.location.assign("/login"); }
  }
  return <AuthContext.Provider value={{ user, setUser, loading, login, register, logout }}><Routes><Route path="/login" element={user ? <Navigate to="/" replace /> : <Login />} /><Route path="/register" element={user ? <Navigate to="/" replace /> : <Register />} /><Route element={<ProtectedLayout />}><Route path="/" element={<Dashboard user={user} />} /><Route path="/documents" element={<Documents />} /><Route path="/upload" element={<Upload />} /><Route path="/personal-information" element={<PersonalInfo />} /><Route path="/profile" element={<Profile />} /><Route path="*" element={<Navigate to="/" replace />} /></Route></Routes></AuthContext.Provider>;
}

export default function App() {
  return <BrowserRouter><AppRoutes /></BrowserRouter>;
}
