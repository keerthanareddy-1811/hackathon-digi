const API_URL = import.meta.env.VITE_API_URL || `${window.location.protocol}//${window.location.hostname}:5000/api`;

async function request(path, options = {}) {
  const response = await fetch(`${API_URL}${path}`, {
    credentials: "include",
    ...options,
    headers: {
      ...(options.body instanceof FormData ? {} : { "Content-Type": "application/json" }),
      ...options.headers,
    },
  });
  const contentType = response.headers.get("content-type") || "";
  const payload = contentType.includes("application/json") ? await response.json() : null;
  if (!response.ok) throw new Error(payload?.error || "Something went wrong. Please try again.");
  return payload;
}

export const api = {
  me: () => request("/me"),
  login: (data) => request("/login", { method: "POST", body: JSON.stringify(data) }),
  register: (data) => request("/register", { method: "POST", body: JSON.stringify(data) }),
  logout: () => request("/logout", { method: "POST" }),
  profile: () => request("/profile"),
  updateProfile: (data) => request("/profile", { method: "PUT", body: JSON.stringify(data) }),
  documents: (search = "", category = "All") =>
    request(`/documents?search=${encodeURIComponent(search)}&category=${encodeURIComponent(category)}`),
  deleteDocument: (id) => request(`/documents/${id}`, { method: "DELETE" }),
  fileUrl: (id, download = false) =>
    `${API_URL}/documents/${id}${download ? "/download" : ""}`,
};

export function uploadDocument(formData, onProgress) {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", `${API_URL}/documents`);
    xhr.withCredentials = true;
    xhr.upload.onprogress = (event) => {
      if (event.lengthComputable) onProgress(Math.round((event.loaded / event.total) * 100));
    };
    xhr.onload = () => {
      let result = {};
      try { result = xhr.responseText ? JSON.parse(xhr.responseText) : {}; }
      catch { reject(new Error("The server returned an unreadable response. Please try again.")); return; }
      if (xhr.status >= 200 && xhr.status < 300) resolve(result);
      else reject(new Error(result.error || "Upload failed. Please try again."));
    };
    xhr.onerror = () => reject(new Error("Could not connect to the server. Check that the backend is running."));
    xhr.send(formData);
  });
}
