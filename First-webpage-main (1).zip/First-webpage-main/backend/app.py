import os
from pathlib import Path

from flask import Flask, jsonify
from flask_cors import CORS

from database import BASE_DIR
from models import init_db
from routes.auth import auth_bp
from routes.documents import documents_bp
from routes.profile import profile_bp


def create_app():
    app = Flask(__name__)
    app.config["SECRET_KEY"] = os.environ.get(
        "LOCKER_SECRET_KEY", "development-only-change-this-secret"
    )
    app.config["MAX_CONTENT_LENGTH"] = 10 * 1024 * 1024 + 64 * 1024
    app.config["UPLOAD_FOLDER"] = str(BASE_DIR / "uploads")
    app.config["SESSION_COOKIE_HTTPONLY"] = True
    app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
    app.config["SESSION_COOKIE_SECURE"] = os.environ.get("LOCKER_HTTPS", "0") == "1"
    allowed_origins = [
        origin.strip()
        for origin in os.environ.get(
            "FRONTEND_ORIGIN",
            "http://localhost:5173,http://127.0.0.1:5173",
        ).split(",")
        if origin.strip()
    ]
    CORS(
        app,
        resources={r"/api/*": {"origins": allowed_origins}},
        supports_credentials=True,
    )

    @app.errorhandler(413)
    def too_large(_error):
        return jsonify({"error": "File is too large. The maximum size is 10 MB."}), 413

    @app.get("/api/health")
    def health():
        return jsonify({"status": "ok", "prototype": True})

    app.register_blueprint(auth_bp, url_prefix="/api")
    app.register_blueprint(documents_bp, url_prefix="/api")
    app.register_blueprint(profile_bp, url_prefix="/api")
    Path(app.config["UPLOAD_FOLDER"]).mkdir(parents=True, exist_ok=True)
    with app.app_context():
        init_db()
    return app


app = create_app()

if __name__ == "__main__":
    app.run(debug=os.environ.get("FLASK_DEBUG", "1") == "1", port=5000)
