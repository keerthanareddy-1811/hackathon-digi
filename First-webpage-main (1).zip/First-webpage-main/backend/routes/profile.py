from flask import Blueprint, g, jsonify, request

from database import get_db
from routes.auth import login_required

profile_bp = Blueprint("profile", __name__)


@profile_bp.get("/profile")
@login_required
def get_profile():
    with get_db() as db:
        info = db.execute(
            "SELECT phone, college, address FROM personal_information WHERE user_id = ?",
            (g.user["id"],),
        ).fetchone()
    return jsonify({"profile": {**dict(g.user), **dict(info)}})


@profile_bp.put("/profile")
@login_required
def update_profile():
    data = request.get_json(silent=True) or {}
    name = str(data.get("name", "")).strip()
    email = str(data.get("email", "")).strip().lower()
    if not name or not email or "@" not in email:
        return jsonify({"error": "Name and a valid email are required."}), 400
    with get_db() as db:
        duplicate = db.execute(
            "SELECT id FROM users WHERE email = ? AND id != ?", (email, g.user["id"])
        ).fetchone()
        if duplicate:
            return jsonify({"error": "That email address is already in use."}), 409
        db.execute(
            """UPDATE users SET name = ?, email = ?, student_id = ?, department = ?, year = ?
               WHERE id = ?""",
            (
                name,
                email,
                str(data.get("student_id", "")).strip(),
                str(data.get("department", "")).strip(),
                str(data.get("year", "")).strip(),
                g.user["id"],
            ),
        )
        db.execute(
            """UPDATE personal_information SET phone = ?, college = ?, address = ?
               WHERE user_id = ?""",
            (
                str(data.get("phone", "")).strip(),
                str(data.get("college", "")).strip(),
                str(data.get("address", "")).strip(),
                g.user["id"],
            ),
        )
    return get_profile()
