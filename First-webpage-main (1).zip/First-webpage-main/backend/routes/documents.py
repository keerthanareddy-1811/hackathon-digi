import os
import uuid
from datetime import datetime, timezone
from pathlib import Path

from flask import Blueprint, current_app, g, jsonify, request, send_from_directory
from werkzeug.utils import secure_filename

from database import get_db
from routes.auth import login_required

documents_bp = Blueprint("documents", __name__)
CATEGORIES = {
    "Certificates",
    "Mark Sheets",
    "ID Documents",
    "Resume",
    "Projects",
    "Internship",
    "Other",
}
ALLOWED_EXTENSIONS = {"pdf", "jpg", "jpeg", "png", "doc", "docx"}
MAX_FILE_SIZE = 10 * 1024 * 1024


def document_payload(row):
    return dict(row)


@documents_bp.get("/documents")
@login_required
def list_documents():
    query = str(request.args.get("search", "")).strip()
    category = str(request.args.get("category", "")).strip()
    sql = "SELECT * FROM documents WHERE user_id = ?"
    values = [g.user["id"]]
    if query:
        sql += " AND name LIKE ?"
        values.append(f"%{query}%")
    if category and category != "All":
        sql += " AND category = ?"
        values.append(category)
    sql += " ORDER BY upload_date DESC"
    with get_db() as db:
        rows = db.execute(sql, values).fetchall()
    return jsonify({"documents": [document_payload(row) for row in rows]})


@documents_bp.post("/documents")
@login_required
def upload_document():
    name = str(request.form.get("name", "")).strip()
    category = str(request.form.get("category", "")).strip()
    description = str(request.form.get("description", "")).strip()
    uploaded = request.files.get("file")
    if not name or not uploaded or not uploaded.filename:
        return jsonify({"error": "Add a document name and choose a file."}), 400
    if category not in CATEGORIES:
        return jsonify({"error": "Choose a valid document category."}), 400
    safe_name = secure_filename(uploaded.filename)
    extension = Path(safe_name).suffix.lower().lstrip(".")
    if not extension or extension not in ALLOWED_EXTENSIONS:
        return jsonify({"error": "File type not supported. Choose PDF, JPG, PNG, DOC, or DOCX."}), 400
    content = uploaded.read(MAX_FILE_SIZE + 1)
    if len(content) > MAX_FILE_SIZE:
        return jsonify({"error": "File is too large. The maximum size is 10 MB."}), 413
    filename = f"{uuid.uuid4().hex}.{extension}"
    upload_dir = current_app.config["UPLOAD_FOLDER"]
    os.makedirs(upload_dir, exist_ok=True)
    file_path = Path(upload_dir) / filename
    file_path.write_bytes(content)
    try:
        with get_db() as db:
            cursor = db.execute(
                """INSERT INTO documents
                   (user_id, name, category, filename, file_type, file_size, upload_date, description)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    g.user["id"],
                    name,
                    category,
                    filename,
                    extension.upper(),
                    len(content),
                    datetime.now(timezone.utc).isoformat(),
                    description,
                ),
            )
            row = db.execute(
                "SELECT * FROM documents WHERE id = ? AND user_id = ?",
                (cursor.lastrowid, g.user["id"]),
            ).fetchone()
    except Exception:
        file_path.unlink(missing_ok=True)
        raise
    return jsonify({"document": document_payload(row)}), 201


@documents_bp.get("/documents/<int:document_id>")
@login_required
def view_document(document_id):
    return serve_document(document_id, as_attachment=False)


@documents_bp.get("/documents/<int:document_id>/download")
@login_required
def download_document(document_id):
    return serve_document(document_id, as_attachment=True)


def serve_document(document_id, as_attachment):
    with get_db() as db:
        row = db.execute(
            "SELECT filename FROM documents WHERE id = ? AND user_id = ?",
            (document_id, g.user["id"]),
        ).fetchone()
    if row is None:
        return jsonify({"error": "Document not found."}), 404
    return send_from_directory(
        current_app.config["UPLOAD_FOLDER"],
        row["filename"],
        as_attachment=as_attachment,
    )


@documents_bp.delete("/documents/<int:document_id>")
@login_required
def delete_document(document_id):
    with get_db() as db:
        row = db.execute(
            "SELECT filename FROM documents WHERE id = ? AND user_id = ?",
            (document_id, g.user["id"]),
        ).fetchone()
        if row is None:
            return jsonify({"error": "Document not found."}), 404
        db.execute(
            "DELETE FROM documents WHERE id = ? AND user_id = ?",
            (document_id, g.user["id"]),
        )
    (Path(current_app.config["UPLOAD_FOLDER"]) / row["filename"]).unlink(missing_ok=True)
    return jsonify({"message": "Document deleted."})
