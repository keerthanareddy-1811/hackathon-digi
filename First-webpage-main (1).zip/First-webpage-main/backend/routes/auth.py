import re
from functools import wraps

from flask import Blueprint, g, jsonify, request, session
from werkzeug.security import check_password_hash, generate_password_hash

from database import get_db

auth_bp = Blueprint("auth", __name__)
EMAIL_PATTERN = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def login_required(route):
    @wraps(route)
    def wrapped(*args, **kwargs):
        user_id = session.get("user_id")
        if not user_id:
            return jsonify({"error": "Please log in to continue."}), 401
        with get_db() as db:
            g.user = db.execute(
                "SELECT id, name, email, student_id, department, year FROM users WHERE id = ?",
                (user_id,),
            ).fetchone()
        if g.user is None:
            session.clear()
            return jsonify({"error": "Your session has expired. Please log in again."}), 401
        return route(*args, **kwargs)

    return wrapped


@auth_bp.post("/register")
def register():
    data = request.get_json(silent=True) or {}
    name = str(data.get("name", "")).strip()
    email = str(data.get("email", "")).strip().lower()
    password = str(data.get("password", ""))
    if not name or not EMAIL_PATTERN.match(email) or len(password) < 8:
        return jsonify({"error": "Enter your name, a valid email, and a password of at least 8 characters."}), 400
    with get_db() as db:
        if db.execute("SELECT id FROM users WHERE email = ?", (email,)).fetchone():
            return jsonify({"error": "An account with this email already exists."}), 409
        cursor = db.execute(
            """INSERT INTO users (name, email, password_hash, created_at)
               VALUES (?, ?, ?, strftime('%Y-%m-%dT%H:%M:%f+00:00', 'now'))""",
            (name, email, generate_password_hash(password)),
        )
        user_id = cursor.lastrowid
        db.execute("INSERT INTO personal_information (user_id) VALUES (?)", (user_id,))
    session["user_id"] = user_id
    return jsonify({"user": user_payload(user_id)}), 201


def user_payload(user_id):
    with get_db() as db:
        row = db.execute(
            "SELECT id, name, email, student_id, department, year FROM users WHERE id = ?",
            (user_id,),
        ).fetchone()
    return dict(row)


@auth_bp.post("/login")
def login():
    data = request.get_json(silent=True) or {}
    email = str(data.get("email", "")).strip().lower()
    password = str(data.get("password", ""))
    with get_db() as db:
        user = db.execute("SELECT id, password_hash FROM users WHERE email = ?", (email,)).fetchone()
    if user is None or not check_password_hash(user["password_hash"], password):
        return jsonify({"error": "The email or password is incorrect."}), 401
    session.clear()
    session["user_id"] = user["id"]
    return jsonify({"user": user_payload(user["id"])})


@auth_bp.post("/logout")
def logout():
    session.clear()
    return jsonify({"message": "You have been logged out."})


@auth_bp.get("/me")
@login_required
def me():
    return jsonify({"user": dict(g.user)})
