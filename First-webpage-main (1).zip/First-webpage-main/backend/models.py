from datetime import datetime, timezone

from database import BASE_DIR, get_db


def make_demo_pdf():
    stream = b"BT /F1 12 Tf 20 50 Td (Demo academic transcript) Tj ET\n"
    objects = [
        b"<</Type/Catalog/Pages 2 0 R>>",
        b"<</Type/Pages/Kids[3 0 R]/Count 1>>",
        b"<</Type/Page/Parent 2 0 R/MediaBox[0 0 300 100]/Contents 4 0 R"
        b"/Resources<</Font<</F1 5 0 R>>>>>>",
        b"<</Length " + str(len(stream)).encode() + b">>stream\n" + stream + b"endstream",
        b"<</Type/Font/Subtype/Type1/BaseFont/Helvetica>>",
    ]
    pdf = bytearray(b"%PDF-1.4\n")
    offsets = [0]
    for index, body in enumerate(objects, start=1):
        offsets.append(len(pdf))
        pdf.extend(f"{index} 0 obj\n".encode() + body + b"\nendobj\n")

    xref_offset = len(pdf)
    pdf.extend(f"xref\n0 {len(offsets)}\n".encode())
    pdf.extend(b"0000000000 65535 f \n")
    for offset in offsets[1:]:
        pdf.extend(f"{offset:010} 00000 n \n".encode())
    pdf.extend(
        f"trailer\n<</Size {len(offsets)}/Root 1 0 R>>\n"
        f"startxref\n{xref_offset}\n%%EOF\n".encode()
    )
    return bytes(pdf)


def init_db():
    """Create the schema and seed a safe-to-share demo account once."""
    with get_db() as db:
        db.executescript(
            """
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                email TEXT NOT NULL UNIQUE COLLATE NOCASE,
                password_hash TEXT NOT NULL,
                student_id TEXT NOT NULL DEFAULT '',
                department TEXT NOT NULL DEFAULT '',
                year TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS personal_information (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
                phone TEXT NOT NULL DEFAULT '',
                college TEXT NOT NULL DEFAULT '',
                address TEXT NOT NULL DEFAULT ''
            );
            CREATE TABLE IF NOT EXISTS documents (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                name TEXT NOT NULL,
                category TEXT NOT NULL,
                filename TEXT NOT NULL,
                file_type TEXT NOT NULL,
                file_size INTEGER NOT NULL,
                upload_date TEXT NOT NULL,
                description TEXT NOT NULL DEFAULT ''
            );
            """
        )

        existing = db.execute(
            "SELECT id FROM users WHERE email = ?", ("demo@student.edu",)
        ).fetchone()
        if existing:
            return

        from werkzeug.security import generate_password_hash

        created_at = datetime.now(timezone.utc).isoformat()
        cursor = db.execute(
            """INSERT INTO users
               (name, email, password_hash, student_id, department, year, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (
                "Aarav Sharma",
                "demo@student.edu",
                generate_password_hash("Student123!"),
                "STU2024001",
                "Computer Science",
                "3rd Year",
                created_at,
            ),
        )
        user_id = cursor.lastrowid
        db.execute(
            "INSERT INTO personal_information (user_id, phone, college, address) VALUES (?, ?, ?, ?)",
            (user_id, "+1 555 014 2024", "Northstar College", "Campus residence"),
        )

        upload_dir = BASE_DIR / "uploads"
        upload_dir.mkdir(parents=True, exist_ok=True)
        demo_filename = "demo-transcript.pdf"
        demo_file = upload_dir / demo_filename
        if not demo_file.exists():
            demo_file.write_bytes(make_demo_pdf())
        db.execute(
            """INSERT INTO documents
               (user_id, name, category, filename, file_type, file_size, upload_date, description)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                user_id,
                "Academic transcript",
                "Mark Sheets",
                demo_filename,
                "PDF",
                demo_file.stat().st_size,
                created_at,
                "Sample document included with the demo account.",
            ),
        )
